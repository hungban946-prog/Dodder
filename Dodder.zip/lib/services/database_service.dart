import 'package:supabase_flutter/supabase_flutter.dart';

class DatabaseService {
  static final supabase = Supabase.instance.client;

  // Tạo cặp đôi mới (người tạo)
  static Future<void> createCouple({
    required String user1Id,
    required String code,
  }) async {
    await supabase.from('couples').insert({
      'user1_id': user1Id,
      'pair_code': code,
      'status': 'waiting', // waiting, active
      'created_at': DateTime.now().toIso8601String(),
    });
  }

  // Tham gia cặp đôi (người nhập mã)
  static Future<void> joinCouple({
    required String user2Id,
    required String code,
  }) async {
    // Tìm couple với mã này và status = 'waiting'
    final response = await supabase
        .from('couples')
        .select()
        .eq('pair_code', code)
        .eq('status', 'waiting')
        .maybeSingle();

    if (response == null) {
      throw Exception('Mã không hợp lệ hoặc đã hết hạn');
    }

    // Cập nhật user2 và chuyển status thành active
    await supabase.from('couples').update({
      'user2_id': user2Id,
      'status': 'active',
    }).eq('id', response['id']);
  }
}